# ImageLogger
Discord image logger private still works in 2022
